import type {
  EvidenceSpanV1, NarrativeEvidenceSourceV1, NarrativeIRBundleV1, NarrativeRecordV1, SemanticRefV1,
} from '../types/narrative-ir'
import { FACT_PREDICATE_REGISTRY } from '../registry/fact-predicate-registry'
import { PROJECT_TABLES } from '../registry/project-tables'
import type { FactPredicateSpec } from '../types/temporal-fact'
import { isPublicWorldCode } from '../workspace/identity'
import { narrativeOwnerKeyV1, parseNarrativeSemanticIdV1 } from './narrative-identity'
import { parseNarrativeIRBundleV1, parseNarrativeRecordV1 } from './narrative-ir-codec'
import { arrayV1, assertNarrativeJsonV1, canonicalNarrativeJsonV1, hashNarrativeBytesV1, hashNarrativeValueV1, hashNarrativeValueWithoutKeysV1, keyV1, narrativeFail, objectV1, pointerV1, textV1 } from './narrative-json'
import { validateNarrativeTimeReferencesV1 } from './narrative-time'

const UNBOUND_HASH = '0'.repeat(64)
const sourceKey = (source: Pick<NarrativeEvidenceSourceV1, 'sourceResourceKey' | 'sourceRevision' | 'fieldPointer'>) =>
  canonicalNarrativeJsonV1([source.sourceResourceKey, source.sourceRevision, source.fieldPointer])

// Only this module can mint a receipt, after complete verification. Both the
// bundle and its exact source array are private, deeply frozen copies. A clone,
// imported artifact, changed source array or changed predicate contract cannot
// reuse it. Weak keys do not keep completed compiler artifacts alive.
const immutableVerification = new WeakMap<NarrativeIRBundleV1, {
  sources: readonly NarrativeEvidenceSourceV1[]; predicatesJson: string; identityContract: string
}>()
const identityContract = () => canonicalNarrativeJsonV1(PROJECT_TABLES.filter(spec => spec.resourceIdentity)
  .map(spec => ({ table: spec.name, identity: spec.resourceIdentity })))
function freezePrivateJson<T>(value: T): T {
  if (value && typeof value === 'object') {
    for (const child of Object.values(value)) freezePrivateJson(child)
    Object.freeze(value)
  }
  return value
}
function parseEvidenceSources(sources: readonly NarrativeEvidenceSourceV1[]): NarrativeEvidenceSourceV1[] {
  assertNarrativeJsonV1(sources)
  return arrayV1(objectV1<NarrativeEvidenceSourceV1>({ sourceResourceKey: keyV1, sourceRevision: keyV1,
    fieldPointer: pointerV1, text: textV1 }))(sources, 'sources')
}

/** Hash local content first. ALL resolved semantic-ref hashes are bound later,
 * so reciprocal relations/contradictions do not introduce hash recursion. */
export async function hashNarrativeRecordV1(input: NarrativeRecordV1): Promise<string> {
  return hashParsedNarrativeRecord(parseNarrativeRecordV1(input))
}
/** Only caller-private output of the exact decoder reaches these helpers.
 * Public hashing and verification still decode untrusted input first. */
async function hashParsedNarrativeRecord(record: NarrativeRecordV1): Promise<string> {
  return hashNarrativeValueWithoutKeysV1(record, ['revisionHash', 'revisionVectorHash'])
}
export async function hashNarrativeBundleV1(input: NarrativeIRBundleV1): Promise<string> {
  return hashParsedNarrativeBundle(parseNarrativeIRBundleV1(input))
}
async function hashParsedNarrativeBundle(bundle: NarrativeIRBundleV1): Promise<string> {
  const { semanticRootHash: _root, ...content } = bundle
  return hashNarrativeValueV1(content)
}

export async function verifyNarrativeEvidenceV1(evidence: EvidenceSpanV1, source: NarrativeEvidenceSourceV1): Promise<void> {
  return verifyEvidenceBytes(evidence, source, new TextEncoder().encode(source.text))
}
async function verifyEvidenceBytes(evidence: EvidenceSpanV1, source: NarrativeEvidenceSourceV1,
  bytes: Uint8Array, sourceContentHash?: string): Promise<void> {
  if (sourceKey(evidence) !== sourceKey(source)) narrativeFail('evidence-source', '证据源/字段/版本不一致')
  if (evidence.normalizationVersion !== 'raw-utf8-v1' || !Number.isSafeInteger(evidence.start)
    || !Number.isSafeInteger(evidence.end) || evidence.start < 0 || evidence.end <= evidence.start || evidence.end > bytes.length) {
    narrativeFail('evidence-span', '原文跨度必须非空、合法且在原始 UTF-8 范围内')
  }
  const boundary = (position: number) => position === bytes.length || (bytes[position] & 0xc0) !== 0x80
  if (!boundary(evidence.start) || !boundary(evidence.end)) narrativeFail('evidence-boundary', '证据不能切开 UTF-8 码点')
  const currentHash = sourceContentHash ?? await hashNarrativeBytesV1(source.text)
  const spanHash = evidence.start === 0 && evidence.end === bytes.length
    ? currentHash : await hashNarrativeBytesV1(bytes.subarray(evidence.start, evidence.end))
  if (currentHash !== evidence.sourceContentHash || spanHash !== evidence.spanHash) {
    narrativeFail('evidence-hash', '原文/证据 hash 不符')
  }
}

/** Verifies an isolated compiler artifact. This does not grant publishability,
 * permissions, author confirmation or v4 release status. */
export async function verifyNarrativeIRBundleV1(
  input: unknown, sources: readonly NarrativeEvidenceSourceV1[],
  predicates: readonly FactPredicateSpec[] = FACT_PREDICATE_REGISTRY,
): Promise<NarrativeIRBundleV1> {
  const receipt = input && typeof input === 'object' ? immutableVerification.get(input as NarrativeIRBundleV1) : undefined
  if (receipt && receipt.sources === sources && receipt.predicatesJson === canonicalNarrativeJsonV1(predicates)
    && receipt.identityContract === identityContract()) {
    return input as NarrativeIRBundleV1
  }
  return verifyParsedNarrativeBundle(parseNarrativeIRBundleV1(input), sources, predicates)
}
async function verifyParsedNarrativeBundle(
  bundle: NarrativeIRBundleV1, sources: readonly NarrativeEvidenceSourceV1[], predicates: readonly FactPredicateSpec[],
  compiledHashes?: { records: ReadonlyMap<string, string>; semanticRootHash: string },
): Promise<NarrativeIRBundleV1> {
  const records = new Map(bundle.records.map(r => [r.semanticId, r]))
  const evidenceById = new Map(bundle.evidence.map(e => [e.evidenceId, e]))
  const checkedSources = parseEvidenceSources(sources)
  const sourceMap = new Map(checkedSources.map(s => [sourceKey(s), s]))
  if (sourceMap.size !== sources.length) narrativeFail('duplicate-source', '冻结原文来源重复')
  // Exact decoding above owns these strings. Cache bytes/digests only for
  // this invocation, so repeated proofs and provenance checks share work
  // without trusting a caller's mutable source or a previous verification.
  const sourceBytes = new Map<NarrativeEvidenceSourceV1, Uint8Array>()
  const sourceHashes = new Map<NarrativeEvidenceSourceV1, Promise<string>>()
  const bytesFor = (source: NarrativeEvidenceSourceV1) => {
    let bytes = sourceBytes.get(source)
    if (!bytes) { bytes = new TextEncoder().encode(source.text); sourceBytes.set(source, bytes) }
    return bytes
  }
  const hashFor = (source: NarrativeEvidenceSourceV1) => {
    let hash = sourceHashes.get(source)
    if (!hash) { hash = hashNarrativeBytesV1(source.text); sourceHashes.set(source, hash) }
    return hash
  }
  const requireEvidence = (ids: string[]) => {
    if (ids.some(id => !evidenceById.has(id))) narrativeFail('evidence-missing', '引用的证据不在闭包内')
  }
  const lookup = (id: string, revisionHash: string) => {
    const target = records.get(id)
    if (!target) narrativeFail('reference-missing', '语义引用缺失或跨 owner/branch')
    if (target.revisionHash !== revisionHash) narrativeFail('stale-reference', '依赖目标 revisionHash 已变化')
    return target
  }
  const namespace = narrativeOwnerKeyV1(bundle.scope.owner)
  const uidSpellings = new Map<string, string>()
  for (const record of bundle.records) {
    const uid = parseNarrativeSemanticIdV1(record.semanticId).source.sourceUid
    const previous = uidSpellings.get(uid.toLowerCase())
    if (previous && previous !== uid) narrativeFail('duplicate-uid', '同一 UID 使用不同大小写声明多个身份')
    uidSpellings.set(uid.toLowerCase(), uid)
  }
  for (const sequence of bundle.timeContext.sequences) {
    if (sequence.ownerKey !== namespace) narrativeFail('sequence-owner', 'sequence owner 与 bundle 不符')
  }
  const worldKeys = new Set([namespace, ...bundle.records.filter(r => r.kind === 'entity' && r.payload.entityType === 'world-group')
    .map(r => parseNarrativeSemanticIdV1(r.semanticId).source.sourceUid)])
  if (bundle.scope.worldGroupKey !== null && !worldKeys.has(bundle.scope.worldGroupKey)) narrativeFail('world-group', '子世界缺少稳定身份声明')
  for (const timeline of bundle.timeContext.timelines) {
    if (!worldKeys.has(timeline.worldKey) || timeline.branchKey !== bundle.scope.branchKey) narrativeFail('timeline-scope', '时间体系 scope/branch 不符')
  }
  for (const anchor of bundle.timeContext.anchors) {
    if (records.get(anchor.eventKey)?.kind !== 'event') narrativeFail('anchor-reference', '时间 anchor 必须指向本包事件')
  }
  for (const mapping of bundle.timeContext.mappings) requireEvidence(mapping.evidenceIds)
  for (const evidence of bundle.evidence) {
    const source = sourceMap.get(sourceKey(evidence))
    if (!source) narrativeFail('evidence-source', '缺少冻结原文')
    await verifyEvidenceBytes(evidence, source, bytesFor(source), await hashFor(source))
  }
  for (const record of bundle.records) {
    const recordHash = compiledHashes?.records.get(record.semanticId) ?? await hashParsedNarrativeRecord(record)
    if (recordHash !== record.revisionHash) narrativeFail('record-hash', '记录 hash 不符')
    validateNarrativeTimeReferencesV1(record.time, bundle.timeContext)
    requireEvidence(record.evidenceIds)
    const provenanceSource = sourceMap.get(sourceKey({ sourceResourceKey: record.provenance.sourceResourceKey,
      sourceRevision: record.provenance.sourceRevision, fieldPointer: record.provenance.sourceField }))
    if (!provenanceSource || await hashFor(provenanceSource) !== record.provenance.sourceContentHash) {
      narrativeFail('provenance-hash', '来源字段/版本/原文 hash 不匹配')
    }
    const narration = record.time.narratedAt
    if (narration) {
      const spans = record.evidenceIds.map(id => evidenceById.get(id)!)
        .filter(e => e.sourceResourceKey.endsWith(`:${narration.unitKey}`))
      if (!spans.some(span => {
        const bytes = bytesFor(sourceMap.get(sourceKey(span))!)
        return narration.spanStart >= span.start && narration.spanStart < span.end
          && (bytes[narration.spanStart] & 0xc0) !== 0x80
      })) narrativeFail('narration-evidence', '叙述 offset 必须落在本记录关联的原文证据码点内')
    }
    for (const dependency of record.dependencies) lookup(dependency.semanticId, dependency.revisionHash)
    forEachParsedRecordReference(record, ref => {
      if (lookup(ref.semanticId, ref.revisionHash).kind !== ref.kind) narrativeFail('ref-kind', '语义目标类型不符')
    })
    if (record.kind === 'assertion') {
      const predicate = predicates.find(item => item.key === record.payload.predicateKey)
      if (!predicate) narrativeFail('predicate-unregistered', '未知 predicate 不能进入已验证合同')
      const kind = record.payload.value.kind
      const acceptedKind = predicate.valueType === 'string' ? 'text' : predicate.valueType === 'number' ? 'decimal' : predicate.valueType
      if (kind !== acceptedKind || (kind === 'enum' && record.payload.value.kind === 'enum'
        && !predicate.enums?.includes(record.payload.value.value))) narrativeFail('predicate-value', '值不符合谓词注册类型')
      for (const prior of record.payload.supersedesRefs) {
        const previous = lookup(prior.semanticId, prior.revisionHash)
        if (previous.kind !== 'assertion' || previous.payload.subjectRef.semanticId !== record.payload.subjectRef.semanticId
          || previous.payload.predicateKey !== record.payload.predicateKey) narrativeFail('supersedes', '只能替代同一主体/谓词的历史状态')
      }
    }
    if (record.kind === 'rule' && record.payload.strength === 'hard') {
      // No narrative hard-rule executors are registered in NW-1A. Do not turn
      // a model-supplied validator name into a proof of executable semantics.
      narrativeFail('validator-unavailable', 'NW-1A 不注册硬规则执行器；保留 advisory 或等待后续领域注册')
    }
    if (record.kind === 'development') requireEvidence(record.payload.resolutionEvidenceIds)
    if (record.kind === 'disclosure') {
      requireEvidence([record.payload.spanRef])
      validateNarrativeTimeReferencesV1({ occurred: null, valid: null, narratedAt: null, acquiredAt: null,
        disclosedAt: record.payload.audienceKeys.map(audienceKey => ({ audienceKey, sequenceKey: record.payload.sequenceKey, unitKey: record.payload.unitKey })) }, bundle.timeContext)
      const span = evidenceById.get(record.payload.spanRef)!
      if (!span.sourceResourceKey.endsWith(`:${record.payload.unitKey}`)) narrativeFail('disclosure-evidence', '揭示证据不属于指定冻结 unit')
    }
  }
  const aliasSources = new Set<string>()
  const mergeEdges = new Map<string, string>()
  for (const alias of bundle.aliases) {
    const target = records.get(alias.toSemanticId)
    if (!target) narrativeFail('alias-target', 'alias 目标不在当前 bundle')
    const from = alias.from
    const sourceId = from.kind === 'semantic' ? from.semanticId : canonicalNarrativeJsonV1(from)
    if (aliasSources.has(sourceId)) narrativeFail('alias-conflict', '同一身份存在多个 alias')
    aliasSources.add(sourceId)
    if (from.kind === 'legacy-release') {
      if (alias.reason !== 'legacy' || !isPublicWorldCode(from.worldCode)
        || bundle.scope.owner.kind !== 'world' || from.worldCode !== bundle.scope.owner.worldCode) narrativeFail('alias-legacy', 'legacy alias 必须绑定原世界/release hash/key')
    } else {
      const origin = parseNarrativeSemanticIdV1(from.semanticId), to = parseNarrativeSemanticIdV1(alias.toSemanticId)
      if (from.semanticId === alias.toSemanticId || origin.kind !== to.kind
        || (alias.reason === 'merge' ? origin.ownerKey !== to.ownerKey
          : alias.reason !== 'derivation' || origin.ownerKey === to.ownerKey)) narrativeFail('alias-scope', '合并保持 namespace；派生必须显式换 namespace')
      if (alias.reason === 'derivation' && origin.ownerKey.startsWith('work/') && bundle.scope.owner.kind === 'world'
        && origin.ownerKey !== `work/${bundle.scope.owner.sourceWorkCode}`) narrativeFail('alias-lineage', '作品派生 alias 与 sourceWorkCode 不一致')
      if (records.has(from.semanticId)) lookup(from.semanticId, from.revisionHash)
      mergeEdges.set(from.semanticId, alias.toSemanticId)
    }
  }
  for (const origin of mergeEdges.keys()) {
    const seen = new Set<string>()
    let next: string | undefined = origin
    while (next !== undefined) {
      if (seen.has(next)) narrativeFail('alias-cycle', 'alias 存在环')
      seen.add(next); next = mergeEdges.get(next)
    }
  }
  const rootHash = compiledHashes?.semanticRootHash ?? await hashParsedNarrativeBundle(bundle)
  if (rootHash !== bundle.semanticRootHash) narrativeFail('root-hash', 'IR bundle root 不符')
  return bundle
}

/** Only private output of the exact IR decoder reaches this traversal.
 * The callbacks below are internal and cannot expose or replace a record.
 * Public reference helpers retain their validation and copy semantics. */
function forEachParsedRecordReference(record: NarrativeRecordV1, visit: (ref: SemanticRefV1) => void): void {
  const walk = (value: unknown): void => {
    if (Array.isArray(value)) { for (const item of value) walk(item); return }
    if (!value || typeof value !== 'object') return
    const object = value as Record<string, unknown>, keys = Object.keys(object)
    // Exact-decoded TypedValues cannot contain arbitrary ref-shaped objects.
    if (keys.length === 3 && typeof object.semanticId === 'string'
      && typeof object.revisionHash === 'string' && typeof object.kind === 'string') {
      visit(object as unknown as SemanticRefV1)
      return
    }
    for (const key of keys) walk(object[key])
  }
  walk(record)
}

/** Bind only version hashes on decoder-owned data, before it is returned. */
function bindParsedRecordReferences(record: NarrativeRecordV1, bind: (id: string, prior: string) => string): void {
  record.revisionHash = bind(record.semanticId, record.revisionHash)
  for (const dependency of record.dependencies) dependency.revisionHash = bind(dependency.semanticId, dependency.revisionHash)
  forEachParsedRecordReference(record, ref => { ref.revisionHash = bind(ref.semanticId, ref.revisionHash) })
}

/** Explicit pure compilation of caller-confirmed typed input, not extraction or
 * persistence. Source/owner capture and adoption remain with NW-1B/1C. */
export async function compileNarrativeIRBundleV1(
  input: Omit<NarrativeIRBundleV1, 'schema' | 'irVersion' | 'semanticRootHash'>,
  sources: readonly NarrativeEvidenceSourceV1[],
  predicates: readonly FactPredicateSpec[] = FACT_PREDICATE_REGISTRY,
): Promise<NarrativeIRBundleV1> {
  const bundle = parseNarrativeIRBundleV1({ ...input, schema: 'storyforge.narrative-ir', irVersion: 1, semanticRootHash: UNBOUND_HASH })
  const hashes = new Map<string, string>()
  // Bound live decoder/crypto buffers. The record order and every hash remain
  // independent of scheduling; this is not a limit on accepted record count.
  for (let offset = 0; offset < bundle.records.length; offset += 32) {
    const batch = await Promise.all(bundle.records.slice(offset, offset + 32)
      .map(async record => [record.semanticId, await hashParsedNarrativeRecord(record)] as const))
    for (const [key, hash] of batch) hashes.set(key, hash)
  }
  const hashFor = (id: string) => hashes.get(id) ?? narrativeFail('reference-missing', '编译依赖未闭合')
  const bind = (id: string, prior: string) => {
    const actual = hashFor(id)
    if (prior !== UNBOUND_HASH && prior !== actual) narrativeFail('stale-reference', '显式输入已绑定旧 revision；不能静默重绑')
    return actual
  }
  for (const record of bundle.records) bindParsedRecordReferences(record, bind)
  bundle.semanticRootHash = await hashParsedNarrativeBundle(bundle)
  // These hashes were computed here over decoder-owned data. Binding only
  // changes revision-hash fields excluded from the record digest; no caller
  // can mutate this bundle before it is returned. Reuse those calculations
  // while still checking every reference, evidence span, scope and predicate.
  // Public verification never receives this private argument and re-hashes
  // imported, cloned or otherwise caller-controlled bundles in full.
  return verifyParsedNarrativeBundle(bundle, sources, predicates, { records: hashes, semanticRootHash: bundle.semanticRootHash })
}

/** Compiler-only allocation option, with the same full verification and wire
 * bytes as ordinary compilation. Inputs are copied before the first await.
 * This immutable result may share verification with the next compiler stage;
 * it grants no authority, permissions, author confirmation or publishability. */
export async function compileImmutableNarrativeIRV1(
  input: Parameters<typeof compileNarrativeIRBundleV1>[0],
  sources: readonly NarrativeEvidenceSourceV1[],
  predicates: readonly FactPredicateSpec[] = FACT_PREDICATE_REGISTRY,
): Promise<{ bundle: NarrativeIRBundleV1; sources: NarrativeEvidenceSourceV1[] }> {
  const privateSources = freezePrivateJson(parseEvidenceSources(sources))
  const predicatesJson = canonicalNarrativeJsonV1(predicates)
  const capturedIdentityContract = identityContract()
  const privatePredicates = JSON.parse(predicatesJson) as FactPredicateSpec[]
  const bundle = freezePrivateJson(await compileNarrativeIRBundleV1(input, privateSources, privatePredicates))
  if (capturedIdentityContract === identityContract()) {
    immutableVerification.set(bundle, { sources: privateSources, predicatesJson, identityContract: capturedIdentityContract })
  }
  return { bundle, sources: privateSources }
}
