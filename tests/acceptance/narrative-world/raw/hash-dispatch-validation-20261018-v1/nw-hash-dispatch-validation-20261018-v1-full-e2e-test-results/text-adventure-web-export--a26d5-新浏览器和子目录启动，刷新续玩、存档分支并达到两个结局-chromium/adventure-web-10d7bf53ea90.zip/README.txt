将本文件夹完整上传到静态网站托管平台，入口为 index.html。可放在任意子目录。
玩家不需要 StoryForge 或 API Key。存档保存在当前浏览器，清理浏览器数据会删除存档。
本包不含生产历史；没有上传或发布任何内容。请使用 HTTPS 或本地 HTTP 服务预览，不能直接双击 HTML。
不同作品版本使用独立存档空间；请保留旧版本网址供旧存档继续游玩。
播放器许可：LICENSE.runtime.txt 和 THIRD-PARTY-NOTICES.txt；作品素材权利信息保留在 game.json 中。
