import{e as n,b as s,h as i,d as a}from"./runtime-api-DuSCRNdZ.js";import"./adventure-web-voXzbEmg.js";async function t(e){if(!e.scope)return!1;const o=await a.works.get(e.scope.workId);if(!o)return!1;if(o.projectId!==e.scope.projectId||o.worldId!==e.scope.worldId)throw new Error("[short-novel-context] Work owner 与当前 scope 不一致");return o.kind==="novel"&&o.novelProfile==="short"}async function f(e){if(!e.scope||!await t(e))return"";const o=await n(e.scope);return["【短篇生产合同】",`阶段：${o.phase}；revision=${o.revision}`,o.brief?`已确认 Brief：${JSON.stringify(o.brief)}`:"已确认 Brief：无",o.storyDesign?`已确认故事设计：${JSON.stringify(o.storyDesign)}`:"已确认故事设计：无",o.latestReview?`最近审校：${JSON.stringify(o.latestReview)}`:"最近审校：无"].join(`
`)}async function d(e){if(!e.scope||!await t(e))return"";const o=await s(e.scope);return["【短篇当前结构与正文】",`作品：${o.work.title}；目标 ${o.work.targetWordCount} 字；manuscriptHash=${o.manuscriptHash}`,...o.chapters.map(r=>[`## ${r.stableKey}｜${r.title}｜${r.wordCount} 字`,`结构卡：${r.summary||"未填写"}`,`正文：
${r.contentHtml?i(r.contentHtml):"未写"}`].join(`
`))].join(`

`)}export{d as readShortNovelManuscriptContextV1,f as readShortNovelProductionContextV1};
